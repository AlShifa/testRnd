package demo;

public class Customer {

private CustomerPK pk;
private String address;
public CustomerPK getPk() {
	return pk;
}
public void setPk(CustomerPK pk) {
	this.pk = pk;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}

}
